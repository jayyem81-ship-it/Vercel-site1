<?php
$send="burtonmichael324@gmail.com"// your email address for result
?>